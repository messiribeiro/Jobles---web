const { BrowserWindow, globalShortcut, ipcMain, dialog, app } = require('electron')
const notifier = require('node-notifier')
const { writeFile } = require('fs')


function createWindow() {
  const win = new BrowserWindow({
    width: 250,
    height: 150,

    // width: 500,
    // height: 500,
    webPreferences: {
      nodeIntegration: true,
      nodeIntegration: true,
      contextIsolation: false,
    },
    fullscreenable: false,
    resizable: false,
    frame: false,
    show: false
  })




  //Verificando se há uma outra instância



  // win.webContents.openDevTools()





  // atalho para iniciar o contador

  globalShortcut.register('Control+Pageup', () => {
    console.log('iniciado')
    win.webContents.send('starter')
 
  })



  var times = ['Momentos salvos \n']
  var days = ['Domingo', 'Segunda-feira', 'Terça-feira', 'Quarta-feira', 'Quinta-feira', 'Sexta-feira', 'Sábado']

  globalShortcut.register('Control+Pagedown', () => {
    win.webContents.send('asynchronous-message', { 'SAVED': 'File Saved' });
  })


  ipcMain.on('teste', (event, message) => {
    times.push(message)
    console.log(message)
    notifier.notify({
      title: 'Nussss',
      message: `Ponto de corte criado ${message}`
    })
  })

  var date = new Date()

  ipcMain.on('close-time', async () => {

    openDialog()

    async function openDialog() {
      const { filePath, canceled } = await dialog.showSaveDialog();


      var options = {
        type: 'question',
        buttons: ['&Sim', '&Não'],
        title: 'Sair sem salvar?',
        normalizeAccessKeys: true,
        message: 'Deseja realmente perder todos os seu momentos?'
      };

      if (canceled) {
        dialog.showMessageBox(options).then((choice) => {
          if (choice.response === 0) {
            console.log("sim")
            while (times.length > 1) times.pop()

          } else if (choice.response === 1) {
            openDialog()
          }
        })
      } else {
        times.push(`\nSalvo em: ${date.getDate()}/${date.getMonth() + 1}/${date.getFullYear()}  ${days[date.getDay()]}`)
        writeFile(filePath, times.toString().replace(/,/g, "").replace(/\./g, ""), 'utf-8', (err, result) => {
          console.log(err, result)
          console.log(times)
          while (times.length > 1) times.pop()
        })
      }
    }




  })




  win.loadFile('index.html')
  // win.webContents.openDevTools()






  return win
}

module.exports = createWindow()