const { app, ipcMain, globalShortcut } = require('electron')
const controlWindow = require('./controlWindow')


function App() {


  const win = require('./createWindow.js')
  const tray = require('./Tray.js')



  const { toggle } = controlWindow(win, tray)

  tray.on('click', toggle)
  win.on('blur', win.hide)


  
  
  
}



app.whenReady().then(() => {


  if (!app.requestSingleInstanceLock()) {
    app.quit();
  }

  App()
  

  //   // if(!app.requestSingleInstanceLock()) {
  //   //   console.log('há outra instância aberta')
  //   //   app.on('second-instance', () => {
  //   //     win
  //   //   })
  //   //   app.quit()
  //   // }


})



app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})





