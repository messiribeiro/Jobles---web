const {ipcRenderer} = require('electron');


localStorage.setItem('instance', false)

ipcRenderer.on('new', (event, message) => {
    // ipcRenderer.send('instance', 'tô na voltância')
    console.log('chegou aqui')
})


ipcRenderer.on('starter', () => {
    delay()
})


// const button = document.querySelector('button');
let control = true

// button.addEventListener('click', init())


// const { ipcRenderer } = require('electron');

// ipcRenderer.invoke('teste', console.log('eae'))

let hours = 0
let seconds = 0
let minutes = 0


function delay() {
    let time = setTimeout(init(), 5000)
    clearInterval(time)
    console.log('timeout')
}


function init() {
    // console.log('começou')
    if (control) {
        interval = setInterval(() => {
            seconds += 1
            // console.log('entrou no setInterval')
            if (seconds == 60) minutes += 1, seconds = 0
            if (minutes == 60) hours += 1, minutes = 0

            render(hours, minutes, seconds)

        }, 1000)

        control = false
    } else {
        location.reload()
        ipcRenderer.send('close-time')
    }
}


// FUNÇÃO PARA FORMATAR O NÚMERO

function formatTime(time) {
    return String(time).padStart(2, '0')
}

// FUNÇÃO QUE RENDERIZA O TEMPORIZADR

function render(hours, minutes, seconds) {
    const count = document.querySelector('#counter')

    count.innerHTML = `${formatTime(hours)}:${formatTime(minutes)}:${formatTime(seconds)}`

}





ipcRenderer.on('asynchronous-message', function (event, message) {
    const data = `\n- ${formatTime(hours)}:${formatTime(minutes)}:${formatTime(seconds)}\n`
    console.log(message); // Returns: {'SAVED': 'File Saved'}
    ipcRenderer.send('teste', data)
});











